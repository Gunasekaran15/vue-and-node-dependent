var chai           =         require('chai');
var express        =         require("express");
var bodyParser     =         require("body-parser");
var app            =         express();
var path = require('path');

var kk=[];
app.use(express.static(path.join(__dirname, 'public')));
app.use('/public', express.static('public'));
app.use('/public/javascripts', express.static('public'));
app.use('/public/stylesheets', express.static('public'));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.get('/',function(req,res){
  res.sendFile(__dirname+"/sample1.html");
});
app.get('/company.json',function(req,res){
res.sendFile(__dirname+"/company.json");
});

 app.get('/model.json',function(req,res){
res.sendFile(__dirname+'/model.json');
 });
   
app.listen(3008,function(){
  console.log("Started on PORT 3008");
})
